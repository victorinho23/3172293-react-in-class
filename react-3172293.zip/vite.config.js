import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from "@tailwindcss/vite"
import {fileURLToPath} from "url"
import {dirname, resolve} from "path"

// Crear __dirname compatible Es modules

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename)

// https://vite.dev/config/
export default defineConfig({
  plugins: [react(), tailwindcss()],

  resolve:{
    alias: {
      "@": resolve(__dirname, "src"), // Cuando veas @, interpretalo como src
    }
  }


})

